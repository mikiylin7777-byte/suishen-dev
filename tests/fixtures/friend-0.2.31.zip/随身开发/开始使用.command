#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [ "$#" -eq 0 ]; then
  python3 "$ROOT/工具/portable.pyz" --root "$ROOT" doctor
  python3 "$ROOT/工具/portable.pyz" --root "$ROOT" wizard --if-needed || true
  python3 "$ROOT/工具/portable.pyz" --root "$ROOT" t3-setup --if-needed || true
  python3 "$ROOT/工具/portable.pyz" --root "$ROOT" menu
else
  exec python3 "$ROOT/工具/portable.pyz" --root "$ROOT" "$@"
fi
